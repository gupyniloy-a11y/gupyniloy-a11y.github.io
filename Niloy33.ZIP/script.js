(()=>{
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const WA='8801316313221',reduce=matchMedia('(prefers-reduced-motion:reduce)').matches;
let lang='en';try{lang=localStorage.getItem('lang')==='bn'?'bn':'en'}catch(e){}
function setLang(l){lang=l;document.documentElement.lang=l;try{localStorage.setItem('lang',l)}catch(e){}buildChips();renderTab();renderConst()}
/* intro */
const intro=$('#intro');function closeIntro(){intro.classList.add('gone');document.body.style.overflow='';try{sessionStorage.setItem('seen','1')}catch(e){}}
$('#enter').onclick=closeIntro;$('#skip').onclick=closeIntro;
document.addEventListener('keydown',e=>{if(e.key==='Escape'){closeIntro();closeLB()}});
try{if(sessionStorage.getItem('seen'))intro.classList.add('gone')}catch(e){}
requestAnimationFrame(()=>setTimeout(()=>$('#introfill').style.width='100%',50));
/* stars */
(()=>{const c=$('#stars'),x=c.getContext('2d');let w,h,p=[];const R=()=>{w=c.width=innerWidth;h=c.height=innerHeight;p=Array.from({length:70},()=>({x:Math.random()*w,y:Math.random()*h,r:Math.random()*1.5+.3,s:Math.random()*.25+.05}))};R();addEventListener('resize',R);
function f(){if(intro.classList.contains('gone'))return;x.clearRect(0,0,w,h);p.forEach(a=>{a.y-=a.s;if(a.y<0)a.y=h;x.fillStyle='rgba(232,194,122,'+(a.r/2)+')';x.beginPath();x.arc(a.x,a.y,a.r,0,7);x.fill()});if(!reduce)requestAnimationFrame(f)}f()})();
/* router */
const pages=['home','about','education','teaching','hire','contact'];
function route(){const id=(location.hash||'#home').slice(1);const pg=pages.includes(id)?id:'home';
 $$('.page').forEach(s=>s.classList.toggle('on',s.id==='p-'+pg));
 $$('#menu a').forEach(a=>a.classList.toggle('on',a.dataset.p===pg));
 $('#menu').classList.remove('open');$('#burger').setAttribute('aria-expanded','false');
 scrollTo(0,0);prog();if(pg==='home')counters();document.title=$('#p-'+pg).dataset.title+' — Gupykanta Nandi Niloy'}
addEventListener('hashchange',route);
function prog(){const d=document.documentElement,max=d.scrollHeight-innerHeight,pi=pages.indexOf((location.hash||'#home').slice(1)),pi2=Math.max(pi,0);
 const within=max>0?scrollY/max:1;$('#progress i').style.width=((pi2+within)/pages.length*100)+'%';
 $$('[data-par]').forEach(i=>{if(!reduce)i.style.transform='translateY('+(scrollY*i.dataset.par)+'px)'})}
addEventListener('scroll',prog,{passive:true});
$('#burger').onclick=e=>{const o=$('#menu').classList.toggle('open');e.currentTarget.setAttribute('aria-expanded',o)};
$('#lang').onclick=()=>setLang(lang==='en'?'bn':'en');
/* counters */
function counters(){$$('#stats b').forEach(b=>{const n=+b.dataset.n,d=+(b.dataset.d||0),s=b.dataset.s||'';if(reduce){b.textContent=n.toFixed(d)+s;return}const t0=performance.now();(function f(t){const k=Math.min((t-t0)/1400,1);b.textContent=(n*(1-Math.pow(1-k,3))).toFixed(d)+(k===1?s:'');if(k<1)requestAnimationFrame(f)})(t0)})}
/* story */
$('#morebtn').onclick=e=>{const m=$('#more'),o=m.hidden;m.hidden=!o;e.currentTarget.setAttribute('aria-expanded',o);e.currentTarget.style.display=o?'none':''};
/* constellation */
const C=[
 {en:['Physics & Chemistry','Clear, example-led lessons for Class 6–10 science, from motion and electricity to reactions and the periodic table.'],bn:['পদার্থ ও রসায়ন','৬ষ্ঠ–১০ম শ্রেণির বিজ্ঞানে উদাহরণভিত্তিক পরিষ্কার পাঠ — গতি, বিদ্যুৎ থেকে রাসায়নিক বিক্রিয়া ও পর্যায় সারণি পর্যন্ত।']},
 {en:['Biology & General Math','Biology explained with real-life links, plus step-by-step problem solving in General Math.'],bn:['জীববিজ্ঞান ও সাধারণ গণিত','বাস্তব জীবনের সংযোগসহ জীববিজ্ঞান এবং ধাপে ধাপে গণিত সমাধান।']},
 {en:['Concept-based teaching','I find the idea that did not click, rebuild it simply, then practise until it holds.'],bn:['ধারণাভিত্তিক পাঠদান','যে ধারণাটি বোঝা হয়নি তা খুঁজে বের করে সহজভাবে বুঝিয়ে অনুশীলনে পাকা করি।']},
 {en:['Student care','Personalised routines and patient guidance that match each child’s pace.'],bn:['শিক্ষার্থীর যত্ন','প্রতিটি শিশুর গতি অনুযায়ী ব্যক্তিগত রুটিন ও ধৈর্যশীল দিকনির্দেশনা।']},
 {en:['Exam preparation','Regular tests, notes and guidance for school exams.'],bn:['পরীক্ষার প্রস্তুতি','স্কুল পরীক্ষার জন্য নিয়মিত পরীক্ষা, নোট ও দিকনির্দেশনা।']},
 {en:['2+ years of experience','Active private tutoring for students from Class 1 to Class 10.'],bn:['২+ বছরের অভিজ্ঞতা','১ম থেকে ১০ম শ্রেণির শিক্ষার্থীদের সক্রিয় প্রাইভেট টিউশনি।']}];
let ck=5;function renderConst(){const c=C[ck][lang];$('#cinfo').innerHTML='<b>'+c[0]+'</b>'+c[1];$$('.node').forEach(n=>n.classList.toggle('active',+n.dataset.k===ck))}
$$('.node').forEach(n=>{const go=()=>{ck=+n.dataset.k;renderConst()};n.onclick=go;n.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();go()}}});
/* timeline, cards, id */
$$('#tl button').forEach(b=>b.onclick=()=>{const li=b.parentElement,o=li.classList.toggle('open');b.setAttribute('aria-expanded',o)});
$$('#cards .card').forEach(b=>b.onclick=()=>b.setAttribute('aria-expanded',b.getAttribute('aria-expanded')!=='true'));
$('#idcard').onclick=e=>{const b=e.currentTarget;b.setAttribute('aria-pressed',b.getAttribute('aria-pressed')!=='true')};
/* tabs */
const T=[
 {en:['Understand first','Every lesson begins with why. I use simple examples and everyday links so ideas are understood, not memorised.'],bn:['আগে বুঝি','প্রতিটি পাঠ শুরু হয় “কেন” দিয়ে। সহজ উদাহরণ ও দৈনন্দিন জীবনের সংযোগে ধারণা বোঝানো হয়, মুখস্থ নয়।']},
 {en:['Practise often','Short, regular problem-solving sessions turn understanding into confidence.'],bn:['নিয়মিত অনুশীলন','ছোট ও নিয়মিত সমস্যা সমাধানের মাধ্যমে বোঝাকে আত্মবিশ্বাসে রূপ দিই।']},
 {en:['Test and improve','Regular tests and notes show exactly where to improve before the school exam does.'],bn:['পরীক্ষা ও উন্নতি','নিয়মিত পরীক্ষা ও নোটে বোঝা যায় স্কুল পরীক্ষার আগেই কোথায় উন্নতি দরকার।']},
 {en:['Stay supportive','Patient, caring guidance so students feel safe asking any question.'],bn:['পাশে থাকা','ধৈর্যশীল ও যত্নশীল দিকনির্দেশনা, যাতে শিক্ষার্থী যেকোনো প্রশ্ন নির্ভয়ে করতে পারে।']}];
let tk=0;function renderTab(){const t=T[tk][lang];$('#tabpanel').innerHTML='<b>'+t[0]+'</b>'+t[1];$$('#tabs button').forEach(b=>b.setAttribute('aria-selected',+b.dataset.t===tk))}
$$('#tabs button').forEach(b=>b.onclick=()=>{tk=+b.dataset.t;renderTab()});
/* chips */
const SUBJ=[['Physics','পদার্থবিজ্ঞান'],['Chemistry','রসায়ন'],['Biology','জীববিজ্ঞান'],['General Math','সাধারণ গণিত'],['Bangla','বাংলা'],['ICT','আইসিটি'],['All subjects (except English)','সব বিষয় (ইংরেজি বাদে)']];
const bn=n=>String(n).replace(/\d/g,d=>'০১২৩৪৫৬৭৮৯'[d]);
function buildChips(){const sc=new Set($$('#classes input:checked').map(i=>i.value)),ss=new Set($$('#subjects input:checked').map(i=>i.value));
 $('#classes').innerHTML=Array.from({length:10},(_,i)=>i+1).map(n=>`<label class="chip"><input type="checkbox" value="${n}" ${sc.has(''+n)?'checked':''}><span>${lang==='bn'?bn(n):n}</span></label>`).join('');
 $('#subjects').innerHTML=SUBJ.map((s,i)=>`<label class="chip"><input type="checkbox" value="${i}" ${ss.has(''+i)?'checked':''}><span>${s[lang==='bn'?1:0]}</span></label>`).join('');}
document.addEventListener('change',e=>{const i=e.target;if(i.closest('#subjects')){const all=$('#subjects input[value="6"]');if(i===all&&i.checked)$$('#subjects input').forEach(x=>x.checked=x===all);else if(i!==all&&i.checked)all.checked=false}});
$('#form').onsubmit=e=>{e.preventDefault();const cl=$$('#classes input:checked').map(i=>i.value),sb=$$('#subjects input:checked').map(i=>SUBJ[i.value][0]),er=$('#err');
 if(!$('#fname').value.trim()||!cl.length||!sb.length){er.hidden=false;er.textContent=lang==='bn'?'অনুগ্রহ করে নাম, ক্লাস ও অন্তত একটি বিষয় নির্বাচন করুন।':'Please add your name, at least one class and at least one subject.';return}
 er.hidden=true;const m=`Hello Niloy, I would like to inquire about home tutoring.\nName: ${$('#fname').value.trim()}\nArea: ${$('#farea').value.trim()||'-'}\nClass: ${cl.join(', ')}\nSubjects: ${sb.join(', ')}\nNote: ${$('#fnote').value.trim()||'-'}`;
 open('https://wa.me/'+WA+'?text='+encodeURIComponent(m),'_blank','noopener')};
/* lightbox */
const lb=$('#lightbox');function closeLB(){lb.hidden=true}
$$('[data-lb]').forEach(b=>b.onclick=()=>{$('#lbimg').src=b.dataset.lb;$('#lbimg').alt=b.dataset['cap'+(lang==='bn'?'Bn':'En')];$('#lbcap').textContent=$('#lbimg').alt;lb.hidden=false;$('#lbclose').focus()});
$('#lbclose').onclick=closeLB;lb.onclick=e=>{if(e.target===lb)closeLB()};
setLang(lang);route();
})();
